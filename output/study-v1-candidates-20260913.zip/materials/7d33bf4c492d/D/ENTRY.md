# Supplied materials

This directory is the assigned read-only material package. Task scope and the common material-access policy take precedence.

Guidance: [guidance.md](guidance.md).

## Reference index

- [references/README.md](references/README.md)
- [references/api-migration-0.1.2-alpha.2.md](references/api-migration-0.1.2-alpha.2.md)
- [references/host-plane-probes.md](references/host-plane-probes.md)
- [references/migration-hygiene.md](references/migration-hygiene.md)
- [references/pre-flight-patterns.json](references/pre-flight-patterns.json)
- [references/pre-flight.md](references/pre-flight.md)
- [references/rollup-0.1.2.md](references/rollup-0.1.2.md)
- [references/troubleshooting.md](references/troubleshooting.md)
- [references/v0.1.1-rc.2.md](references/v0.1.1-rc.2.md)
- [references/v0.1.2-alpha.1.md](references/v0.1.2-alpha.1.md)
- [references/v0.1.2-alpha.2.md](references/v0.1.2-alpha.2.md)

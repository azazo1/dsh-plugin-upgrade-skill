# Supplied materials

This directory is the assigned read-only material package. Task scope and the common material-access policy take precedence.

No migration guidance or reference documents are supplied.

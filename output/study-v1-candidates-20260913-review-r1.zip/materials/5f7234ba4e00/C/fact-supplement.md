# Source-derived factual supplement

This supplement restates facts in the same pinned entry document. It adds no task
answers or task-specific instructions. It is supplied identically to C and D.

- Source repository identity (owner/repository or URL) and registry package identity
  (scope/package) are separate coordinates; one does not determine the other.
- Package manifests and lockfiles describe packages and dependencies.
  `dsh-plugin.json`, when adopted, is the community-standard manifest.
  `cordis.patch.yml`, `agent.cordis.yml`, and historical `cordis.yml` describe
  profile composition. Resolved configuration is the runtime composition result.
- Successful dependency installation alone does not establish plugin enablement:
  profile composition resolution and runtime entry activation are distinct states.

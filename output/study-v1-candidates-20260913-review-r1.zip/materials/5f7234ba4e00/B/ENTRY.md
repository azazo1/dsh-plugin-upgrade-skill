# Supplied materials

This directory is the assigned read-only material package. Task scope and the common material-access policy take precedence.

Guidance: [guidance.md](guidance.md).
